TapIt Android SDK

Complete implementation instructions can be found at:
https://github.com/tapit/TapIt-Android-SDK-Source
